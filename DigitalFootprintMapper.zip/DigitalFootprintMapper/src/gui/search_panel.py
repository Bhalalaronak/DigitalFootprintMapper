"""
Search panel for DigitalFootprintMapper
"""

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QFormLayout, QLineEdit, 
                           QCheckBox, QGroupBox, QPushButton, QLabel,
                           QComboBox, QSpinBox, QScrollArea)
from PyQt5.QtCore import pyqtSignal, Qt

class SearchPanel(QWidget):
    """Panel for search inputs and controls"""
    
    # Signal emitted when search is requested
    search_requested = pyqtSignal(dict)
    
    def __init__(self):
        super().__init__()
        
        # Set up the layout
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(10, 10, 10, 10)
        
        # Create title
        title = QLabel("Search Parameters")
        title.setStyleSheet("font-size: 16px; font-weight: bold;")
        self.layout.addWidget(title)
        
        # Create scroll area for search options
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout(scroll_content)
        
        # Basic search inputs
        basic_group = QGroupBox("Basic Information")
        basic_layout = QFormLayout()
        
        self.username_input = QLineEdit()
        basic_layout.addRow("Username:", self.username_input)
        
        self.email_input = QLineEdit()
        basic_layout.addRow("Email:", self.email_input)
        
        self.name_input = QLineEdit()
        basic_layout.addRow("Real Name:", self.name_input)
        
        self.phone_input = QLineEdit()
        basic_layout.addRow("Phone Number:", self.phone_input)
        
        basic_group.setLayout(basic_layout)
        scroll_layout.addWidget(basic_group)
        
        # Platform selection
        platforms_group = QGroupBox("Platforms to Search")
        platforms_layout = QVBoxLayout()
        
        # Social Media
        social_label = QLabel("Social Media:")
        social_label.setStyleSheet("font-weight: bold;")
        platforms_layout.addWidget(social_label)
        
        self.platform_twitter = QCheckBox("Twitter")
        self.platform_twitter.setChecked(True)
        platforms_layout.addWidget(self.platform_twitter)
        
        self.platform_instagram = QCheckBox("Instagram")
        self.platform_instagram.setChecked(True)
        platforms_layout.addWidget(self.platform_instagram)
        
        self.platform_facebook = QCheckBox("Facebook")
        self.platform_facebook.setChecked(True)
        platforms_layout.addWidget(self.platform_facebook)
        
        self.platform_linkedin = QCheckBox("LinkedIn")
        self.platform_linkedin.setChecked(True)
        platforms_layout.addWidget(self.platform_linkedin)
        
        self.platform_tiktok = QCheckBox("TikTok")
        self.platform_tiktok.setChecked(True)
        platforms_layout.addWidget(self.platform_tiktok)
        
        self.platform_reddit = QCheckBox("Reddit")
        self.platform_reddit.setChecked(True)
        platforms_layout.addWidget(self.platform_reddit)
        
        # Forums and Communities
        forums_label = QLabel("Forums and Communities:")
        forums_label.setStyleSheet("font-weight: bold;")
        platforms_layout.addWidget(forums_label)
        
        self.platform_github = QCheckBox("GitHub")
        self.platform_github.setChecked(True)
        platforms_layout.addWidget(self.platform_github)
        
        self.platform_stackoverflow = QCheckBox("Stack Overflow")
        self.platform_stackoverflow.setChecked(True)
        platforms_layout.addWidget(self.platform_stackoverflow)
        
        self.platform_quora = QCheckBox("Quora")
        platforms_layout.addWidget(self.platform_quora)
        
        # Content Platforms
        content_label = QLabel("Content Platforms:")
        content_label.setStyleSheet("font-weight: bold;")
        platforms_layout.addWidget(content_label)
        
        self.platform_youtube = QCheckBox("YouTube")
        self.platform_youtube.setChecked(True)
        platforms_layout.addWidget(self.platform_youtube)
        
        self.platform_medium = QCheckBox("Medium")
        platforms_layout.addWidget(self.platform_medium)
        
        self.platform_wordpress = QCheckBox("WordPress")
        platforms_layout.addWidget(self.platform_wordpress)
        
        # Gaming Platforms
        gaming_label = QLabel("Gaming Platforms:")
        gaming_label.setStyleSheet("font-weight: bold;")
        platforms_layout.addWidget(gaming_label)
        
        self.platform_steam = QCheckBox("Steam")
        platforms_layout.addWidget(self.platform_steam)
        
        self.platform_discord = QCheckBox("Discord")
        platforms_layout.addWidget(self.platform_discord)
        
        self.platform_twitch = QCheckBox("Twitch")
        platforms_layout.addWidget(self.platform_twitch)
        
        platforms_group.setLayout(platforms_layout)
        scroll_layout.addWidget(platforms_group)
        
        # Search options
        options_group = QGroupBox("Search Options")
        options_layout = QFormLayout()
        
        self.search_depth = QComboBox()
        self.search_depth.addItems(["Basic", "Standard", "Deep", "Comprehensive"])
        self.search_depth.setCurrentIndex(1)  # Standard by default
        options_layout.addRow("Search Depth:", self.search_depth)
        
        self.max_results = QSpinBox()
        self.max_results.setRange(10, 1000)
        self.max_results.setValue(100)
        self.max_results.setSingleStep(10)
        options_layout.addRow("Max Results per Platform:", self.max_results)
        
        self.include_images = QCheckBox("Include Images")
        self.include_images.setChecked(True)
        options_layout.addRow("", self.include_images)
        
        self.include_content = QCheckBox("Include Content Analysis")
        self.include_content.setChecked(True)
        options_layout.addRow("", self.include_content)
        
        self.include_connections = QCheckBox("Include Connection Analysis")
        self.include_connections.setChecked(True)
        options_layout.addRow("", self.include_connections)
        
        options_group.setLayout(options_layout)
        scroll_layout.addWidget(options_group)
        
        # Add some spacing
        scroll_layout.addStretch()
        
        # Set the scroll area content
        scroll_area.setWidget(scroll_content)
        self.layout.addWidget(scroll_area)
        
        # Search button
        self.search_button = QPushButton("Start Search")
        self.search_button.setMinimumHeight(40)
        self.search_button.clicked.connect(self.on_search_clicked)
        self.layout.addWidget(self.search_button)
    
    def on_search_clicked(self):
        """Handle search button click"""
        # Collect search parameters
        search_params = {
            'username': self.username_input.text(),
            'email': self.email_input.text(),
            'name': self.name_input.text(),
            'phone': self.phone_input.text(),
            'platforms': {
                'twitter': self.platform_twitter.isChecked(),
                'instagram': self.platform_instagram.isChecked(),
                'facebook': self.platform_facebook.isChecked(),
                'linkedin': self.platform_linkedin.isChecked(),
                'tiktok': self.platform_tiktok.isChecked(),
                'reddit': self.platform_reddit.isChecked(),
                'github': self.platform_github.isChecked(),
                'stackoverflow': self.platform_stackoverflow.isChecked(),
                'quora': self.platform_quora.isChecked(),
                'youtube': self.platform_youtube.isChecked(),
                'medium': self.platform_medium.isChecked(),
                'wordpress': self.platform_wordpress.isChecked(),
                'steam': self.platform_steam.isChecked(),
                'discord': self.platform_discord.isChecked(),
                'twitch': self.platform_twitch.isChecked()
            },
            'search_depth': self.search_depth.currentText(),
            'max_results': self.max_results.value(),
            'include_images': self.include_images.isChecked(),
            'include_content': self.include_content.isChecked(),
            'include_connections': self.include_connections.isChecked()
        }
        
        # Emit signal with search parameters
        self.search_requested.emit(search_params)
    
    def clear(self):
        """Clear all inputs"""
        self.username_input.clear()
        self.email_input.clear()
        self.name_input.clear()
        self.phone_input.clear()
