"""
Main application window for DigitalFootprintMapper
"""

from PyQt5.QtWidgets import (QMainWindow, QTabWidget, QVBoxLayout, QHBoxLayout, 
                           QWidget, QStatusBar, QToolBar, QAction, QFileDialog,
                           QMessageBox)
from PyQt5.QtCore import Qt, QSize
from PyQt5.QtGui import QIcon

from .search_panel import SearchPanel
from .results_panel import ResultsPanel

class MainWindow(QMainWindow):
    """Main application window"""
    
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("DigitalFootprintMapper - Digital Footprint Analysis Tool")
        self.setMinimumSize(1200, 800)
        
        # Create central widget and main layout
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.main_layout = QHBoxLayout(self.central_widget)
        
        # Create search panel (left side)
        self.search_panel = SearchPanel()
        self.search_panel.search_requested.connect(self.perform_search)
        self.main_layout.addWidget(self.search_panel, 1)
        
        # Create results panel (right side)
        self.results_panel = ResultsPanel()
        self.main_layout.addWidget(self.results_panel, 3)
        
        # Create status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready")
        
        # Create toolbar
        self.create_toolbar()
        
        # Create menu
        self.create_menu()
    
    def create_toolbar(self):
        """Create the main toolbar"""
        toolbar = QToolBar("Main Toolbar")
        toolbar.setIconSize(QSize(24, 24))
        self.addToolBar(toolbar)
        
        # Add actions
        new_search_action = QAction("New Search", self)
        new_search_action.triggered.connect(self.new_search)
        toolbar.addAction(new_search_action)
        
        save_action = QAction("Save Results", self)
        save_action.triggered.connect(self.save_results)
        toolbar.addAction(save_action)
        
        load_action = QAction("Load Results", self)
        load_action.triggered.connect(self.load_results)
        toolbar.addAction(load_action)
        
        export_action = QAction("Export Report", self)
        export_action.triggered.connect(self.export_report)
        toolbar.addAction(export_action)
    
    def create_menu(self):
        """Create the application menu"""
        menu_bar = self.menuBar()
        
        # File menu
        file_menu = menu_bar.addMenu("&File")
        
        new_search_action = QAction("&New Search", self)
        new_search_action.setShortcut("Ctrl+N")
        new_search_action.triggered.connect(self.new_search)
        file_menu.addAction(new_search_action)
        
        save_action = QAction("&Save Results", self)
        save_action.setShortcut("Ctrl+S")
        save_action.triggered.connect(self.save_results)
        file_menu.addAction(save_action)
        
        load_action = QAction("&Load Results", self)
        load_action.setShortcut("Ctrl+O")
        load_action.triggered.connect(self.load_results)
        file_menu.addAction(load_action)
        
        file_menu.addSeparator()
        
        export_menu = file_menu.addMenu("Export")
        
        export_pdf_action = QAction("Export as PDF", self)
        export_pdf_action.triggered.connect(lambda: self.export_report("pdf"))
        export_menu.addAction(export_pdf_action)
        
        export_html_action = QAction("Export as HTML", self)
        export_html_action.triggered.connect(lambda: self.export_report("html"))
        export_menu.addAction(export_html_action)
        
        export_csv_action = QAction("Export Data as CSV", self)
        export_csv_action.triggered.connect(lambda: self.export_report("csv"))
        export_menu.addAction(export_csv_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("E&xit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Tools menu
        tools_menu = menu_bar.addMenu("&Tools")
        
        settings_action = QAction("&Settings", self)
        settings_action.triggered.connect(self.show_settings)
        tools_menu.addAction(settings_action)
        
        # Help menu
        help_menu = menu_bar.addMenu("&Help")
        
        about_action = QAction("&About", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
    
    def new_search(self):
        """Start a new search"""
        self.search_panel.clear()
        self.results_panel.clear()
        self.status_bar.showMessage("Ready for new search")
    
    def perform_search(self, search_params):
        """Perform a search with the given parameters"""
        self.status_bar.showMessage(f"Searching for {search_params['username']}...")
        
        # In a real implementation, this would call the collectors and analyzers
        # For now, we'll simulate some results
        self.results_panel.set_subject(search_params['username'])
        
        # Simulate collecting data
        self.status_bar.showMessage("Collecting data from platforms...")
        
        # Simulate analyzing data
        self.status_bar.showMessage("Analyzing collected data...")
        
        # Simulate generating visualizations
        self.status_bar.showMessage("Generating visualizations...")
        
        # Update results panel with simulated data
        self.results_panel.update_with_simulated_data(search_params)
        
        self.status_bar.showMessage(f"Search completed for {search_params['username']}")
    
    def save_results(self):
        """Save the current results"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save Results", "", "DigitalFootprintMapper Files (*.dfm)"
        )
        
        if file_path:
            # In a real implementation, this would save the results to a file
            self.status_bar.showMessage(f"Results saved to {file_path}")
    
    def load_results(self):
        """Load saved results"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load Results", "", "DigitalFootprintMapper Files (*.dfm)"
        )
        
        if file_path:
            # In a real implementation, this would load results from a file
            self.status_bar.showMessage(f"Results loaded from {file_path}")
    
    def export_report(self, format_type="pdf"):
        """Export a report in the specified format"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, f"Export Report as {format_type.upper()}", 
            "", f"{format_type.upper()} Files (*.{format_type})"
        )
        
        if file_path:
            # In a real implementation, this would generate and save a report
            self.status_bar.showMessage(f"Report exported to {file_path}")
    
    def show_settings(self):
        """Show settings dialog"""
        QMessageBox.information(self, "Settings", "Settings dialog would be shown here.")
    
    def show_about(self):
        """Show about dialog"""
        QMessageBox.about(
            self,
            "About DigitalFootprintMapper",
            "DigitalFootprintMapper v1.0\n\n"
            "A comprehensive OSINT tool for mapping digital footprints.\n\n"
            "This tool visualizes a subject's online presence across websites, "
            "forums, and social media platforms."
        )
