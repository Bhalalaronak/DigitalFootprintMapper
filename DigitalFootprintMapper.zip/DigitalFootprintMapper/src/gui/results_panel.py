"""
Results panel for DigitalFootprintMapper
"""

import random
import matplotlib
matplotlib.use('Qt5Agg')
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import networkx as nx

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QTabWidget, QLabel, 
                           QScrollArea, QGridLayout, QGroupBox)
from PyQt5.QtCore import Qt

class MatplotlibCanvas(FigureCanvas):
    """Matplotlib canvas for embedding plots in PyQt"""
    
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = self.fig.add_subplot(111)
        
        super(MatplotlibCanvas, self).__init__(self.fig)
        self.setParent(parent)
        
        self.fig.tight_layout()

class ResultsPanel(QWidget):
    """Panel for displaying search results and visualizations"""
    
    def __init__(self):
        super().__init__()
        
        self.subject = None
        
        # Set up the layout
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(10, 10, 10, 10)
        
        # Create header
        self.header_label = QLabel("No Search Results")
        self.header_label.setStyleSheet("font-size: 18px; font-weight: bold;")
        self.layout.addWidget(self.header_label)
        
        # Create tab widget for results
        self.tabs = QTabWidget()
        
        # Dashboard tab
        self.dashboard_tab = QWidget()
        self.dashboard_layout = QVBoxLayout(self.dashboard_tab)
        self.tabs.addTab(self.dashboard_tab, "Dashboard")
        
        # Platform Usage tab
        self.platform_tab = QWidget()
        self.platform_layout = QVBoxLayout(self.platform_tab)
        self.tabs.addTab(self.platform_tab, "Platform Usage")
        
        # Network Graph tab
        self.network_tab = QWidget()
        self.network_layout = QVBoxLayout(self.network_tab)
        self.tabs.addTab(self.network_tab, "Network Graph")
        
        # Content Analysis tab
        self.content_tab = QWidget()
        self.content_layout = QVBoxLayout(self.content_tab)
        self.tabs.addTab(self.content_tab, "Content Analysis")
        
        # Timeline tab
        self.timeline_tab = QWidget()
        self.timeline_layout = QVBoxLayout(self.timeline_tab)
        self.tabs.addTab(self.timeline_tab, "Timeline")
        
        # Add tabs to layout
        self.layout.addWidget(self.tabs)
        
        # Initialize with empty state
        self.clear()
    
    def set_subject(self, subject):
        """Set the subject of the search"""
        self.subject = subject
        self.header_label.setText(f"Digital Footprint: {subject}")
    
    def clear(self):
        """Clear all results"""
        self.subject = None
        self.header_label.setText("No Search Results")
        
        # Clear dashboard tab
        self.clear_layout(self.dashboard_layout)
        empty_dashboard = QLabel("No data to display. Start a search to see results.")
        empty_dashboard.setAlignment(Qt.AlignCenter)
        self.dashboard_layout.addWidget(empty_dashboard)
        
        # Clear platform usage tab
        self.clear_layout(self.platform_layout)
        
        # Clear network graph tab
        self.clear_layout(self.network_layout)
        
        # Clear content analysis tab
        self.clear_layout(self.content_layout)
        
        # Clear timeline tab
        self.clear_layout(self.timeline_layout)
    
    def clear_layout(self, layout):
        """Clear all widgets from a layout"""
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
    
    def update_with_simulated_data(self, search_params):
        """Update the results panel with simulated data"""
        # Clear previous results
        self.clear_layout(self.dashboard_layout)
        self.clear_layout(self.platform_layout)
        self.clear_layout(self.network_layout)
        self.clear_layout(self.content_layout)
        self.clear_layout(self.timeline_layout)
        
        # Update dashboard
        self.update_dashboard(search_params)
        
        # Update platform usage
        self.update_platform_usage(search_params)
        
        # Update network graph
        self.update_network_graph(search_params)
        
        # Update content analysis
        self.update_content_analysis(search_params)
        
        # Update timeline
        self.update_timeline(search_params)
    
    def update_dashboard(self, search_params):
        """Update the dashboard tab with summary information"""
        # Create summary section
        summary_group = QGroupBox("Digital Footprint Summary")
        summary_layout = QVBoxLayout()
        
        # Add summary text
        username = search_params['username']
        summary_text = f"Digital footprint analysis for: <b>{username}</b><br><br>"
        summary_text += f"<b>Platforms Found:</b> {random.randint(5, 12)} platforms<br>"
        summary_text += f"<b>Total Accounts:</b> {random.randint(8, 20)} accounts<br>"
        summary_text += f"<b>Activity Level:</b> {'High' if random.random() > 0.5 else 'Medium'}<br>"
        summary_text += f"<b>First Online Presence:</b> {2010 + random.randint(0, 10)}<br>"
        summary_text += f"<b>Most Active Platform:</b> {'Twitter' if random.random() > 0.5 else 'Reddit'}<br>"
        
        summary_label = QLabel(summary_text)
        summary_layout.addWidget(summary_label)
        summary_group.setLayout(summary_layout)
        self.dashboard_layout.addWidget(summary_group)
        
        # Create platform distribution chart
        platform_chart = MatplotlibCanvas(width=5, height=4)
        platforms = ['Twitter', 'Reddit', 'GitHub', 'LinkedIn', 'Instagram']
        values = [random.randint(5, 30) for _ in range(len(platforms))]
        
        platform_chart.axes.bar(platforms, values, color='skyblue')
        platform_chart.axes.set_title('Platform Activity Distribution')
        platform_chart.axes.set_ylabel('Activity Score')
        platform_chart.fig.tight_layout()
        
        self.dashboard_layout.addWidget(platform_chart)
        
        # Add stretch to push everything to the top
        self.dashboard_layout.addStretch()
    
    def update_platform_usage(self, search_params):
        """Update the platform usage tab with charts and statistics"""
        # Create platform usage pie chart
        usage_chart = MatplotlibCanvas(width=6, height=5)
        
        # Generate simulated data
        platforms = []
        sizes = []
        
        for platform, checked in search_params['platforms'].items():
            if checked and random.random() > 0.3:  # 70% chance to "find" the platform
                platforms.append(platform.capitalize())
                sizes.append(random.randint(5, 30))
        
        if not platforms:
            platforms = ['No Data']
            sizes = [1]
        
        # Create pie chart
        usage_chart.axes.pie(sizes, labels=platforms, autopct='%1.1f%%', 
                           startangle=90, shadow=True)
        usage_chart.axes.set_title('Platform Usage Distribution')
        usage_chart.axes.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle
        
        self.platform_layout.addWidget(usage_chart)
        
        # Create activity heatmap
        activity_chart = MatplotlibCanvas(width=8, height=4)
        
        # Generate simulated data
        days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        hours = list(range(24))
        
        data = [[random.randint(0, 10) for _ in range(len(days))] for _ in range(len(hours))]
        
        # Create heatmap
        im = activity_chart.axes.imshow(data, cmap='YlOrRd')
        activity_chart.axes.set_title('Activity Heatmap (Hour of Day vs Day of Week)')
        activity_chart.axes.set_xticks(range(len(days)))
        activity_chart.axes.set_xticklabels(days)
        activity_chart.axes.set_yticks(range(0, 24, 3))
        activity_chart.axes.set_yticklabels([f"{h}:00" for h in range(0, 24, 3)])
        activity_chart.fig.colorbar(im, ax=activity_chart.axes, label='Activity Level')
        activity_chart.fig.tight_layout()
        
        self.platform_layout.addWidget(activity_chart)
        
        # Add stretch to push everything to the top
        self.platform_layout.addStretch()
    
    def update_network_graph(self, search_params):
        """Update the network graph tab with connection visualizations"""
        # Create network graph visualization
        network_chart = MatplotlibCanvas(width=8, height=6)
        
        # Generate a random graph
        G = nx.Graph()
        
        # Add central node (the subject)
        G.add_node(search_params['username'], type='subject')
        
        # Add platform nodes
        platforms = []
        for platform, checked in search_params['platforms'].items():
            if checked and random.random() > 0.3:  # 70% chance to "find" the platform
                node_name = f"{platform}_{search_params['username']}"
                G.add_node(node_name, type='platform')
                G.add_edge(search_params['username'], node_name)
                platforms.append(node_name)
        
        # Add some random connections
        for _ in range(random.randint(5, 15)):
            if platforms:
                platform = random.choice(platforms)
                connection = f"connection_{random.randint(1000, 9999)}"
                G.add_node(connection, type='connection')
                G.add_edge(platform, connection)
        
        # Draw the graph
        pos = nx.spring_layout(G)
        
        # Draw nodes with different colors based on type
        node_colors = []
        for node in G.nodes():
            node_type = G.nodes[node].get('type')
            if node_type == 'subject':
                node_colors.append('red')
            elif node_type == 'platform':
                node_colors.append('blue')
            else:
                node_colors.append('green')
        
        # Draw the network
        nx.draw_networkx(
            G, pos, ax=network_chart.axes,
            node_color=node_colors,
            node_size=500,
            font_size=8,
            with_labels=True
        )
        
        network_chart.axes.set_title('Connection Network')
        network_chart.axes.axis('off')  # Turn off axis
        
        self.network_layout.addWidget(network_chart)
        
        # Add explanation
        explanation = QLabel(
            "<b>Network Graph Explanation:</b><br>"
            "• Red node: Subject (center)<br>"
            "• Blue nodes: Platforms where the subject has accounts<br>"
            "• Green nodes: Connections (other users, websites, etc.)<br>"
            "<br>This graph shows how the subject's online presence is interconnected."
        )
        self.network_layout.addWidget(explanation)
        
        # Add stretch to push everything to the top
        self.network_layout.addStretch()
    
    def update_content_analysis(self, search_params):
        """Update the content analysis tab with text analysis visualizations"""
        # Create word frequency chart
        word_chart = MatplotlibCanvas(width=8, height=4)
        
        # Generate simulated data
        words = ['technology', 'security', 'privacy', 'data', 'social', 'media', 
                'online', 'digital', 'internet', 'computer', 'software', 'web',
                'network', 'cyber', 'information', 'system', 'user', 'profile']
        frequencies = [random.randint(5, 50) for _ in range(len(words))]
        
        # Sort by frequency
        sorted_data = sorted(zip(words, frequencies), key=lambda x: x[1])
        sorted_words, sorted_freqs = zip(*sorted_data)
        
        # Create horizontal bar chart
        word_chart.axes.barh(sorted_words, sorted_freqs, color='skyblue')
        word_chart.axes.set_title('Most Frequent Words in Content')
        word_chart.axes.set_xlabel('Frequency')
        word_chart.fig.tight_layout()
        
        self.content_layout.addWidget(word_chart)
        
        # Create sentiment analysis chart
        sentiment_chart = MatplotlibCanvas(width=6, height=4)
        
        # Generate simulated data
        platforms = ['Twitter', 'Reddit', 'GitHub', 'LinkedIn', 'Instagram']
        positive = [random.uniform(0.3, 0.8) for _ in range(len(platforms))]
        neutral = [random.uniform(0.1, 0.4) for _ in range(len(platforms))]
        negative = [1 - (p + n) for p, n in zip(positive, neutral)]
        
        # Create stacked bar chart
        sentiment_chart.axes.bar(platforms, positive, label='Positive', color='green')
        sentiment_chart.axes.bar(platforms, neutral, bottom=positive, label='Neutral', color='gray')
        sentiment_chart.axes.bar(platforms, negative, bottom=[p+n for p, n in zip(positive, neutral)], 
                               label='Negative', color='red')
        
        sentiment_chart.axes.set_title('Sentiment Analysis by Platform')
        sentiment_chart.axes.set_ylabel('Proportion')
        sentiment_chart.axes.legend()
        sentiment_chart.fig.tight_layout()
        
        self.content_layout.addWidget(sentiment_chart)
        
        # Add stretch to push everything to the top
        self.content_layout.addStretch()
    
    def update_timeline(self, search_params):
        """Update the timeline tab with activity timeline"""
        # Create activity timeline chart
        timeline_chart = MatplotlibCanvas(width=10, height=5)
        
        # Generate simulated data
        years = list(range(2015, 2024))
        platforms = ['Twitter', 'Reddit', 'GitHub', 'LinkedIn', 'Instagram']
        
        # Create a dictionary to store activity by platform and year
        activity_data = {}
        for platform in platforms:
            if random.random() > 0.3:  # 70% chance to include platform
                activity_data[platform] = [random.randint(0, 100) if random.random() > 0.2 else 0 
                                         for _ in range(len(years))]
        
        # Plot activity lines
        for platform, activities in activity_data.items():
            timeline_chart.axes.plot(years, activities, marker='o', linewidth=2, label=platform)
        
        timeline_chart.axes.set_title('Activity Timeline by Platform')
        timeline_chart.axes.set_xlabel('Year')
        timeline_chart.axes.set_ylabel('Activity Level')
        timeline_chart.axes.legend()
        timeline_chart.axes.grid(True, linestyle='--', alpha=0.7)
        timeline_chart.fig.tight_layout()
        
        self.timeline_layout.addWidget(timeline_chart)
        
        # Create significant events section
        events_group = QGroupBox("Significant Events")
        events_layout = QVBoxLayout()
        
        # Generate random events
        event_years = sorted(random.sample(years, min(5, len(years))))
        events = [
            f"<b>{event_years[0]}:</b> First appeared online on {random.choice(list(activity_data.keys()))}",
            f"<b>{event_years[1]}:</b> Significant increase in activity on {random.choice(list(activity_data.keys()))}",
            f"<b>{event_years[2]}:</b> Started using {random.choice(list(activity_data.keys()))}",
        ]
        
        if len(event_years) > 3:
            events.append(f"<b>{event_years[3]}:</b> Peak activity period across multiple platforms")
        
        if len(event_years) > 4:
            events.append(f"<b>{event_years[4]}:</b> Most recent significant activity")
        
        events_text = "<br>".join(events)
        events_label = QLabel(events_text)
        events_layout.addWidget(events_label)
        events_group.setLayout(events_layout)
        
        self.timeline_layout.addWidget(events_group)
        
        # Add stretch to push everything to the top
        self.timeline_layout.addStretch()
