"""
Base collector class for DigitalFootprintMapper
"""

class BaseCollector:
    """Base class for all data collectors"""
    
    def __init__(self):
        self.results = {}
        self.errors = []
    
    def collect(self, search_params):
        """
        Main collection method to be implemented by subclasses
        
        Args:
            search_params (dict): Search parameters
            
        Returns:
            dict: Collection results
        """
        raise NotImplementedError("Subclasses must implement collect() method")
    
    def get_results(self):
        """Get collection results"""
        return self.results
    
    def get_errors(self):
        """Get collection errors"""
        return self.errors
    
    def add_error(self, error_message):
        """Add an error message"""
        self.errors.append(error_message)
    
    def clear(self):
        """Clear results and errors"""
        self.results = {}
        self.errors = []
