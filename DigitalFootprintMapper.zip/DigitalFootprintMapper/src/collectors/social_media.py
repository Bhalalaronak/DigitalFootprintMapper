"""
Social media collectors for DigitalFootprintMapper
"""

import random
import time
from datetime import datetime, timedelta
from .base_collector import BaseCollector

class TwitterCollector(BaseCollector):
    """Collector for Twitter data"""
    
    def collect(self, search_params):
        """Collect Twitter data"""
        username = search_params.get('username')
        if not username:
            self.add_error("No username provided for Twitter search")
            return {}
        
        # In a real implementation, this would use Twitter API or web scraping
        # For now, we'll simulate data collection
        
        # Simulate API call delay
        time.sleep(0.5)
        
        # Simulate whether the account exists (80% chance if username is provided)
        account_exists = random.random() < 0.8
        
        if not account_exists:
            return {}
        
        # Generate simulated Twitter data
        twitter_data = {
            'platform': 'twitter',
            'username': username,
            'profile_url': f"https://twitter.com/{username}",
            'account_found': True,
            'account_info': {
                'display_name': username.capitalize(),
                'bio': "This is a simulated Twitter bio for demonstration purposes.",
                'location': random.choice(["New York, NY", "San Francisco, CA", "London, UK", ""]),
                'joined_date': f"{random.randint(2006, 2022)}-{random.randint(1, 12):02d}",
                'followers_count': random.randint(10, 10000),
                'following_count': random.randint(10, 1000),
                'tweets_count': random.randint(50, 5000),
                'verified': random.random() < 0.1,  # 10% chance of being verified
            },
            'recent_activity': self._generate_recent_activity(50)
        }
        
        self.results = twitter_data
        return twitter_data
    
    def _generate_recent_activity(self, count):
        """Generate simulated recent activity"""
        activity = []
        
        for i in range(count):
            # Generate a random date within the last year
            days_ago = random.randint(0, 365)
            activity_date = datetime.now() - timedelta(days=days_ago)
            
            activity.append({
                'type': random.choice(['tweet', 'retweet', 'reply']),
                'date': activity_date.strftime("%Y-%m-%d %H:%M:%S"),
                'content': f"This is simulated tweet content #{i+1}",
                'likes': random.randint(0, 100),
                'retweets': random.randint(0, 20)
            })
        
        # Sort by date (newest first)
        return sorted(activity, key=lambda x: x['date'], reverse=True)

class InstagramCollector(BaseCollector):
    """Collector for Instagram data"""
    
    def collect(self, search_params):
        """Collect Instagram data"""
        username = search_params.get('username')
        if not username:
            self.add_error("No username provided for Instagram search")
            return {}
        
        # In a real implementation, this would use Instagram API or web scraping
        # For now, we'll simulate data collection
        
        # Simulate API call delay
        time.sleep(0.5)
        
        # Simulate whether the account exists (70% chance if username is provided)
        account_exists = random.random() < 0.7
        
        if not account_exists:
            return {}
        
        # Generate simulated Instagram data
        instagram_data = {
            'platform': 'instagram',
            'username': username,
            'profile_url': f"https://instagram.com/{username}",
            'account_found': True,
            'account_info': {
                'display_name': username.capitalize(),
                'bio': "This is a simulated Instagram bio for demonstration purposes.",
                'posts_count': random.randint(10, 500),
                'followers_count': random.randint(50, 20000),
                'following_count': random.randint(50, 1000),
                'is_private': random.random() < 0.3,  # 30% chance of being private
                'is_verified': random.random() < 0.1,  # 10% chance of being verified
            },
            'recent_posts': self._generate_recent_posts(20)
        }
        
        self.results = instagram_data
        return instagram_data
    
    def _generate_recent_posts(self, count):
        """Generate simulated recent posts"""
        posts = []
        
        for i in range(count):
            # Generate a random date within the last year
            days_ago = random.randint(0, 365)
            post_date = datetime.now() - timedelta(days=days_ago)
            
            posts.append({
                'date': post_date.strftime("%Y-%m-%d %H:%M:%S"),
                'caption': f"This is simulated Instagram post caption #{i+1}",
                'likes': random.randint(10, 1000),
                'comments': random.randint(0, 50),
                'location': random.choice(["New York", "San Francisco", "London", "", ""]),
                'has_image': True,
                'image_url': f"https://example.com/instagram/image_{i+1}.jpg"
            })
        
        # Sort by date (newest first)
        return sorted(posts, key=lambda x: x['date'], reverse=True)

class FacebookCollector(BaseCollector):
    """Collector for Facebook data"""
    
    def collect(self, search_params):
        """Collect Facebook data"""
        username = search_params.get('username')
        name = search_params.get('name')
        
        if not username and not name:
            self.add_error("No username or name provided for Facebook search")
            return {}
        
        # Use name if username is not provided
        search_term = username or name
        
        # In a real implementation, this would use Facebook API or web scraping
        # For now, we'll simulate data collection
        
        # Simulate API call delay
        time.sleep(0.5)
        
        # Simulate whether the account exists (60% chance if search term is provided)
        account_exists = random.random() < 0.6
        
        if not account_exists:
            return {}
        
        # Generate simulated Facebook data
        facebook_data = {
            'platform': 'facebook',
            'username': username or f"{name.lower().replace(' ', '.')}",
            'profile_url': f"https://facebook.com/{username or name.lower().replace(' ', '.')}",
            'account_found': True,
            'account_info': {
                'display_name': name or username.capitalize(),
                'location': random.choice(["New York, NY", "San Francisco, CA", "London, UK", ""]),
                'education': random.choice(["University of Example", "Example College", ""]),
                'work': random.choice(["Example Company", "Self-employed", ""]),
                'joined_date': f"{random.randint(2004, 2022)}",
                'is_public': random.random() < 0.4,  # 40% chance of being public
            },
            'public_activity': self._generate_public_activity(15)
        }
        
        self.results = facebook_data
        return facebook_data
    
    def _generate_public_activity(self, count):
        """Generate simulated public activity"""
        activity = []
        
        for i in range(count):
            # Generate a random date within the last year
            days_ago = random.randint(0, 365)
            activity_date = datetime.now() - timedelta(days=days_ago)
            
            activity.append({
                'type': random.choice(['post', 'shared_post', 'life_event']),
                'date': activity_date.strftime("%Y-%m-%d %H:%M:%S"),
                'content': f"This is simulated Facebook post content #{i+1}",
                'reactions': random.randint(5, 100),
                'comments': random.randint(0, 20)
            })
        
        # Sort by date (newest first)
        return sorted(activity, key=lambda x: x['date'], reverse=True)

class LinkedInCollector(BaseCollector):
    """Collector for LinkedIn data"""
    
    def collect(self, search_params):
        """Collect LinkedIn data"""
        username = search_params.get('username')
        name = search_params.get('name')
        
        if not username and not name:
            self.add_error("No username or name provided for LinkedIn search")
            return {}
        
        # Use name if username is not provided
        search_term = username or name
        
        # In a real implementation, this would use LinkedIn API or web scraping
        # For now, we'll simulate data collection
        
        # Simulate API call delay
        time.sleep(0.5)
        
        # Simulate whether the account exists (75% chance if search term is provided)
        account_exists = random.random() < 0.75
        
        if not account_exists:
            return {}
        
        # Generate simulated LinkedIn data
        linkedin_data = {
            'platform': 'linkedin',
            'username': username or name.lower().replace(' ', '-'),
            'profile_url': f"https://linkedin.com/in/{username or name.lower().replace(' ', '-')}",
            'account_found': True,
            'account_info': {
                'display_name': name or username.replace('-', ' ').title(),
                'headline': random.choice([
                    "Software Engineer", 
                    "Data Scientist", 
                    "Product Manager",
                    "Digital Marketing Specialist",
                    "Cybersecurity Analyst"
                ]),
                'location': random.choice(["New York, NY", "San Francisco, CA", "London, UK"]),
                'connections': random.choice(["500+", "300+", "100+"]),
                'current_company': random.choice(["Tech Corp", "Data Innovations", "Cyber Systems", ""]),
            },
            'experience': self._generate_experience(),
            'education': self._generate_education()
        }
        
        self.results = linkedin_data
        return linkedin_data
    
    def _generate_experience(self):
        """Generate simulated work experience"""
        experience = []
        current_year = datetime.now().year
        
        # Number of jobs (1-4)
        num_jobs = random.randint(1, 4)
        
        for i in range(num_jobs):
            # Each job lasts 1-5 years
            job_duration = random.randint(1, 5)
            end_year = current_year - i
            start_year = end_year - job_duration
            
            experience.append({
                'title': random.choice([
                    "Software Engineer", 
                    "Data Scientist", 
                    "Product Manager",
                    "Digital Marketing Specialist",
                    "Cybersecurity Analyst"
                ]),
                'company': random.choice(["Tech Corp", "Data Innovations", "Cyber Systems", "Global Solutions"]),
                'start_date': f"{start_year}-{random.randint(1, 12):02d}",
                'end_date': "Present" if i == 0 else f"{end_year}-{random.randint(1, 12):02d}",
                'location': random.choice(["New York, NY", "San Francisco, CA", "London, UK", "Remote"]),
                'description': f"This is a simulated job description for position #{i+1}."
            })
        
        return experience
    
    def _generate_education(self):
        """Generate simulated education"""
        education = []
        current_year = datetime.now().year
        
        # Number of education entries (1-2)
        num_entries = random.randint(1, 2)
        
        for i in range(num_entries):
            # Each education lasts 2-4 years
            edu_duration = random.randint(2, 4)
            end_year = current_year - i * 4 - random.randint(0, 10)
            start_year = end_year - edu_duration
            
            education.append({
                'school': random.choice([
                    "University of Example", 
                    "Example State University", 
                    "Technical Institute of Examples",
                    "Example College"
                ]),
                'degree': random.choice([
                    "Bachelor of Science", 
                    "Master of Science", 
                    "Bachelor of Arts",
                    "Master of Business Administration"
                ]),
                'field': random.choice([
                    "Computer Science", 
                    "Information Technology", 
                    "Business Administration",
                    "Data Science",
                    "Cybersecurity"
                ]),
                'start_year': start_year,
                'end_year': end_year
            })
        
        return education

class RedditCollector(BaseCollector):
    """Collector for Reddit data"""
    
    def collect(self, search_params):
        """Collect Reddit data"""
        username = search_params.get('username')
        if not username:
            self.add_error("No username provided for Reddit search")
            return {}
        
        # In a real implementation, this would use Reddit API or web scraping
        # For now, we'll simulate data collection
        
        # Simulate API call delay
        time.sleep(0.5)
        
        # Simulate whether the account exists (65% chance if username is provided)
        account_exists = random.random() < 0.65
        
        if not account_exists:
            return {}
        
        # Generate simulated Reddit data
        reddit_data = {
            'platform': 'reddit',
            'username': username,
            'profile_url': f"https://reddit.com/user/{username}",
            'account_found': True,
            'account_info': {
                'display_name': f"u/{username}",
                'karma': random.randint(100, 50000),
                'cake_day': f"{random.randint(2008, 2022)}-{random.randint(1, 12):02d}-{random.randint(1, 28):02d}",
                'is_gold': random.random() < 0.2,  # 20% chance of having Reddit Gold
            },
            'active_subreddits': self._generate_active_subreddits(),
            'recent_posts': self._generate_recent_posts(15),
            'recent_comments': self._generate_recent_comments(25)
        }
        
        self.results = reddit_data
        return reddit_data
    
    def _generate_active_subreddits(self):
        """Generate list of active subreddits"""
        all_subreddits = [
            "AskReddit", "pics", "news", "worldnews", "funny", "gaming", "movies",
            "science", "todayilearned", "technology", "programming", "python",
            "datascience", "MachineLearning", "cybersecurity", "privacy", "linux",
            "webdev", "javascript", "cscareerquestions", "personalfinance"
        ]
        
        # Select 5-10 random subreddits
        num_subreddits = random.randint(5, 10)
        active_subreddits = random.sample(all_subreddits, num_subreddits)
        
        return [{"name": sr, "url": f"https://reddit.com/r/{sr}"} for sr in active_subreddits]
    
    def _generate_recent_posts(self, count):
        """Generate simulated recent posts"""
        posts = []
        
        for i in range(count):
            # Generate a random date within the last year
            days_ago = random.randint(0, 365)
            post_date = datetime.now() - timedelta(days=days_ago)
            
            subreddit = random.choice([sr["name"] for sr in self._generate_active_subreddits()])
            
            posts.append({
                'subreddit': subreddit,
                'title': f"This is simulated Reddit post title #{i+1}",
                'date': post_date.strftime("%Y-%m-%d %H:%M:%S"),
                'upvotes': random.randint(-5, 1000),
                'comments': random.randint(0, 100),
                'url': f"https://reddit.com/r/{subreddit}/comments/{i+1}"
            })
        
        # Sort by date (newest first)
        return sorted(posts, key=lambda x: x['date'], reverse=True)
    
    def _generate_recent_comments(self, count):
        """Generate simulated recent comments"""
        comments = []
        
        for i in range(count):
            # Generate a random date within the last year
            days_ago = random.randint(0, 365)
            comment_date = datetime.now() - timedelta(days=days_ago)
            
            subreddit = random.choice([sr["name"] for sr in self._generate_active_subreddits()])
            
            comments.append({
                'subreddit': subreddit,
                'content': f"This is simulated Reddit comment content #{i+1}",
                'date': comment_date.strftime("%Y-%m-%d %H:%M:%S"),
                'upvotes': random.randint(-5, 100),
                'url': f"https://reddit.com/r/{subreddit}/comments/{random.randint(1000, 9999)}"
            })
        
        # Sort by date (newest first)
        return sorted(comments, key=lambda x: x['date'], reverse=True)
