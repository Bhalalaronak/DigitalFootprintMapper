#!/usr/bin/env python3
"""
DigitalFootprintMapper - OSINT tool for mapping digital footprints
"""

import sys
import os
from PyQt5.QtWidgets import QApplication
from src.gui.main_window import MainWindow

def main():
    """Main application entry point"""
    # Create application directory if it doesn't exist
    os.makedirs(os.path.join(os.path.dirname(__file__), 'data', 'profiles'), exist_ok=True)
    
    # Create and start the application
    app = QApplication(sys.argv)
    app.setApplicationName("DigitalFootprintMapper")
    app.setOrganizationName("OSINT Tools")
    
    # Create and show the main window
    window = MainWindow()
    window.show()
    
    # Start the application event loop
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
